package errorhandler;

@SuppressWarnings("serial")
public class ArrayIsEmptyExcpetion extends RuntimeException{

	public ArrayIsEmptyExcpetion(String message) {
		super(message);
	}
	
}
